import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Layout from "./Layout";
import Home from "./pages/Home";
import Facility from "./pages/Facility";
import Simulator from "./pages/Simulator";
import Pricing from "./pages/Pricing";
import Access from "./pages/Access";
import Faq from "./pages/Faq";
import Trial from "./pages/Trial";
import Contact from "./pages/Contact";

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/facility" element={<Facility />} />
          <Route path="/simulator" element={<Simulator />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/access" element={<Access />} />
          <Route path="/faq" element={<Faq />} />
          <Route path="/trial" element={<Trial />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Layout>
    </Router>
  );
}